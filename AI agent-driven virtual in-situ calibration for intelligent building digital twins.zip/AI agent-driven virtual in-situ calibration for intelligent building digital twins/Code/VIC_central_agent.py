import os
import sys
import pdfplumber
from langchain_openai import ChatOpenAI
# from langchain.llms import OpenAI  # 수정된 부분
# from langchain.tools import tool  # 수정된 부분
from langchain.prompts import ChatPromptTemplate
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.tools import tool
from langchain.prompts import MessagesPlaceholder
# from langchain_core.output_parsers import StrOutputParser
from langchain.memory import ConversationBufferMemory
from langchain.chains import LLMChain
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

from Benchmark_modeling_tool import Benchmark_modeling_tool
from Correction_modeling_tool import Correction_modeling_tool
from Problem_solving_tool import Problem_solving_tool
from Ontology_tool import Ontology_tool


#%% Input parameter

# OPENAI API KEY 저장
os.environ["OPENAI_API_KEY"] = 'Your api key' #Your api key

#%% tool

@tool
def wrapper_Benchmark_modeling_tool(Calibration_variable: str):
    """Please use this tool to call function to develop the benchmark model in building.

    Args:
        Calibration_variable: str which is calibration variable of MLP model
    """
    return Benchmark_modeling_tool(Calibration_variable)

@tool
def wrapper_Correction_modeling_tool(Calibration_variable: str):
    """Please use this tool to call function to develop the correction model in building.

    Args:
        Calibration_variable: str which is calibration variable of MLP model
    """
    return Correction_modeling_tool(Calibration_variable)

@tool
def wrapper_Problem_solving_tool(Calibration_variable: str):
    """Please use this tool to call function.

    Args:
        Calibration_variable: str which is calibration variable for Bayesian MCMC
    """
    return Problem_solving_tool(Calibration_variable)

@tool
def wrapper_Ontology_tool(question: str):
    """Please use this tool to call function which perform Q&A for calibration result.
    """
    return Ontology_tool(question)

tools = [wrapper_Benchmark_modeling_tool,wrapper_Correction_modeling_tool,wrapper_Problem_solving_tool,wrapper_Ontology_tool]

#%% Prompt, Model, Memory

chat_prompt = ChatPromptTemplate.from_messages(
    [
      ("system", "You are a helpful assistant by using tools or your own knowledge."),
      MessagesPlaceholder(variable_name="chat_history"),
      ("user", '{user_input}'),
      ("system", """If you use tools given by users, do not insert input parameters arbitarily, you must require to users.
                    When user want to know calibration result and sensor relationship, you can invoke wrapper_Ontology_tool
                    When user want to calibrate the physical sensor, firstly you can directly run wrapper_Benchmark_modeling_tool to determine the benchmark model, then, you can directly run wrapper_Correction_modeling_tool to determine correction model expression, you can directly run wrapper_Problem_solving_tool.
                    Notice: The RMSE_AC must is less than 0.5 for different Calibration_variable; else you must run wrapper_Problem_solving_tool again and again, but up to 10 times.
                    Notice: If the Calibration_variable is Chilled_Mass_Flow, the RMSE_AC must is less than 0.1; else you must runwrapper_Problem_solving_tool again and again, but up to 5 times.
                    Finally you can directly run wrapper_Ontology_tool to summarize and explain result of calibration variable.
                    You must give all inputs for Return_Chilled_Water_Temperature_Benchmark_Model including values and points 
                    You must use defined relationship,such as CalibrationApproach, CalibrationEndTime, isInputOf, etc.
                    Meantime, you must give a summary: calibration variable is input of distance model, distance model is input of problem solving, problem solving estimates correction model, correction model calibrates calibration target.
                    Input variables are from Brick schema, VIC is used to calibrate physical sensor and virtual model, physical sensor and virtual model are from Brick schema.
                    You must mention Brick schema when you summarize result.
                    Calibration_variable is same. 
                    
                    
      """),
      MessagesPlaceholder(variable_name="agent_scratchpad")
    ]
)

model = ChatOpenAI(model_name='gpt-4o', temperature=0)
memory = ConversationBufferMemory(return_messages=True, memory_key="chat_history")

#%% Execution

agent = create_tool_calling_agent(model, tools, chat_prompt)

agent_executor = AgentExecutor(agent=agent, tools=tools, memory=memory, verbose=True, max_iteration=5)

while True:
    user_input = input("To chatbot(or enter 'quit' to exit): ")
    if user_input == 'quit':
        break
    result = agent_executor.invoke({"user_input": user_input})




