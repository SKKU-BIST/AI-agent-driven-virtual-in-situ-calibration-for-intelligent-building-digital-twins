def Problem_solving_tool (Calibration_variable):
    import matplotlib.pyplot as plt

    plt.rcParams['font.sans-serif'] = 'Times New Roman'  # font set
    import matplotlib.pyplot as plt
    import numpy as np
    from scipy.stats import multivariate_normal

    plt.rcParams['font.sans-serif'] = 'Times New Roman'  # font set
    import time, os
    from keras.models import load_model
    import pandas as pd
    import pickle
    from rdflib import Graph, Namespace, RDF, Literal
    from rdflib import XSD
    current_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(current_dir, "Input")
    output_dir = os.path.join(current_dir, "Output")

    with open(os.path.join(output_dir,"scaler_X.pkl"), "rb") as f:
        scaler_X = pickle.load(f)

    with open(os.path.join(output_dir,"scaler_y.pkl"), "rb") as f:
        scaler_y = pickle.load(f)

    file_path = os.path.join(output_dir,"Correction_model_expression.txt")
    try:
        with open(file_path, "r") as file:
            Correction_model_expression = file.read().strip()

        print(f"The correction model expression is: {Correction_model_expression}")

    except FileNotFoundError:
        print(f"Error: The file {file_path} was not found.")
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")

    # Define the namespace
    BRICK = Namespace("https://brickschema.org/schema/1.2/Brick#")

    # Load the TTL file
    ttl_file_path = os.path.join(input_dir, "my_building_sensor.ttl")
    g = Graph()
    g.parse(ttl_file_path, format="ttl")

    # Query all objects under the brick1 namespace
    query = """
        SELECT DISTINCT ?object
        WHERE {
            ?s ?p ?object .
            FILTER(STRSTARTS(STR(?object), "https://brickschema.org/schema/1.2/Brick#"))
        }
    """

    # Execute a SPARQL query
    results = g.query(query)

    brick1_objects = [str(row.object).replace("https://brickschema.org/schema/1.2/Brick#", "") for row in results]

    brick1_objects_sorted = sorted(brick1_objects)

    Model = os.path.join(output_dir, f'{Calibration_variable}_VM.h5')
    if os.path.exists(Model):
        model = load_model(Model)
        print(f"Model successfully loaded from: {Model}")
    else:
        print(f"Error: Model file does not exist at {Model}")

    df = pd.read_csv(os.path.join(input_dir, "HVAC operational dataset for final project (final).csv"), index_col=0,
                     header=2, encoding='CP949')

    Input_variable1 = brick1_objects_sorted

    if df.index[0].count('.') == 2:
        df.index = pd.to_datetime(df.index, format="%d.%m.%Y %H:%M")
    else:
        df.index = pd.to_datetime(df.index, format="%m %d %H").map(lambda x: x.replace(year=2022))

    with open(os.path.join(output_dir,"most_correlated_variables1.txt"), "r") as file:
        most_correlated_variable1 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables2.txt"), "r") as file:
        most_correlated_variable2 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables3.txt"), "r") as file:
        most_correlated_variable3 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables4.txt"), "r") as file:
        most_correlated_variable4 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables5.txt"), "r") as file:
        most_correlated_variable5 = file.read()

    Calibration_start_period = '2022-06-21'
    Calibration_end_period = '2022-06-30'

    df1_ = df.loc[Calibration_start_period:Calibration_end_period, :]

    data1 = {
        "Supply_Condenser_Water_Temperature": df1_[Input_variable1].values[:, 28],
        "Return_Condenser_Water_Temperature": df1_[Input_variable1].values[:, 23],
        "Supply_Chilled_Water_Temperature": df1_[Input_variable1].values[:, 27],
        "Return_Chilled_Water_Temperature": df1_[Input_variable1].values[:, 22],
        "Cooling_Mass_Flow": df1_[Input_variable1].values[:, 5],
        "Chilled_Mass_Flow": df1_[Input_variable1].values[:, 1],
        "Power": df1_[Input_variable1].values[:, 19],
        "Cooling_Water_Differential_Pressure": df1_[Input_variable1].values[:, 6],
        "Chilled_water_Differential_Pressure": df1_[Input_variable1].values[:, 4],
        "Fan_Speed": df1_[Input_variable1].values[:, 10],
        "Static_Pressure": df1_[Input_variable1].values[:, 24],
        "Supply_Air_Temperature": df1_[Input_variable1].values[:, 26],
        "Supply_Air_Humidity": df1_[Input_variable1].values[:, 25],
        "Mixed_Air_Temperature": df1_[Input_variable1].values[:, 16],
        "Mixed_Air_Humidity": df1_[Input_variable1].values[:, 15],
        "Outdoor_Air_Temperature": df1_[Input_variable1].values[:, 18],
        "Outdoor_Air_Humidity": df1_[Input_variable1].values[:, 17],
        "Return_Air_Temperature": df1_[Input_variable1].values[:, 21],
        "Return_Air_Humidity": df1_[Input_variable1].values[:, 20],
        "Valve_Opening": df1_[Input_variable1].values[:, 35],
        "Indoor_Air_Temperature1": df1_[Input_variable1].values[:, 12],
        "Indoor_Air_Temperature2": df1_[Input_variable1].values[:, 13],
        "Indoor_Air_Temperature3": df1_[Input_variable1].values[:, 14],
    }

    data1 = pd.DataFrame(data1)
    Calibration_column_1 = data1[most_correlated_variable1]
    Calibration_column_1 = pd.DataFrame(pd.DataFrame(Calibration_column_1))

    Calibration_column_2 = data1[most_correlated_variable2]
    Calibration_column_2 = pd.DataFrame(pd.DataFrame(Calibration_column_2))

    Calibration_column_3 = data1[most_correlated_variable3]
    Calibration_column_3 = pd.DataFrame(pd.DataFrame(Calibration_column_3))

    Calibration_column_4 = data1[most_correlated_variable4]
    Calibration_column_4 = pd.DataFrame(pd.DataFrame(Calibration_column_4))

    Calibration_column_5 = data1[most_correlated_variable5]
    Calibration_column_5 = pd.DataFrame(pd.DataFrame(Calibration_column_5))

    X1_m = Calibration_column_1
    X1_m.columns = [0]

    X2_m = Calibration_column_2
    X2_m.columns = [0]

    X3_m = Calibration_column_3
    X3_m.columns = [0]

    X4_m = Calibration_column_4
    X4_m.columns = [0]

    X5_m = Calibration_column_5
    X5_m.columns = [0]

    y_m = df1_[Calibration_variable].values.reshape(-1, 1)

    X_m = np.c_[X1_m, X2_m, X3_m, X4_m, X5_m]
    X_m = pd.DataFrame(X_m)
    y_pred = scaler_X.transform(X_m)
    y_pred1 = model.predict(y_pred)
    y_pred2 = scaler_y.inverse_transform(y_pred1)

    with open(os.path.join(output_dir,"highest_corr_variable.txt"), "r") as file:
        highest_corr_variable_name = file.read()
    highest_corr_variable = df1_[highest_corr_variable_name].values.reshape(-1, 1)
    highest_corr_variable_all = highest_corr_variable

    def normfun(x, mu, sigma):
        pdf = np.exp(-((x - mu) ** 2) / (2 * sigma ** 2)) / (sigma * np.sqrt(2 * np.pi))
        return pdf

    def LJTACmodel_bench_CS(X, sigma_LH, MeanPrior, SigmaPrior, Faulty_y_m, Faulty_X1_m, Faulty_X2_m, Faulty_X3_m,
                            Faulty_X4_m, Faulty_X5_m, NumberState, highest_corr_variable):
        if Correction_model_expression == "Constant":
            Correction_function = X[0]
            True_y = Faulty_y_m[:, 0] + Correction_function
            True_X_m = np.c_[Faulty_X1_m, Faulty_X2_m, Faulty_X3_m, Faulty_X4_m, Faulty_X5_m]
            X_train_scaled_y_m = scaler_X.transform(True_X_m)
            y_mc = model.predict(X_train_scaled_y_m)
            y_mc = scaler_y.inverse_transform(y_mc)
            y_mc = y_mc[:, 0]
            DQ = np.abs(True_y - y_mc)
            Likeli = normfun(DQ, 0, sigma_LH)
            PR_T1 = normfun(X[0], MeanPrior[0, 0], SigmaPrior[0, 0])
            F = np.prod(Likeli) * (PR_T1)
        elif Correction_model_expression == "Linear":
            Correction_function = X[0] * highest_corr_variable[:, 0] + X[1]
            True_y = Faulty_y_m[:, 0] + Correction_function
            True_X_m = np.c_[Faulty_X1_m, Faulty_X2_m, Faulty_X3_m, Faulty_X4_m, Faulty_X5_m]
            X_train_scaled_y_m = scaler_X.transform(True_X_m)
            y_mc = model.predict(X_train_scaled_y_m)
            y_mc = scaler_y.inverse_transform(y_mc)
            y_mc = y_mc[:, 0]
            DQ = np.abs(True_y - y_mc)
            Likeli = normfun(DQ, 0, sigma_LH)
            PR_T1 = normfun(X[0], MeanPrior[0, 0], SigmaPrior[0, 0])
            PR_T2 = normfun(X[1], MeanPrior[0, 1], SigmaPrior[0, 1])
            F = np.prod(Likeli) * (PR_T1 * PR_T2)
        elif Correction_model_expression == "Polynomial":
            Correction_function = X[0] * highest_corr_variable[:, 0] * highest_corr_variable[:, 0] + X[
                1] * highest_corr_variable[:, 0] + X[2]
            True_y = Faulty_y_m[:, 0] + Correction_function
            True_X_m = np.c_[Faulty_X1_m, Faulty_X2_m, Faulty_X3_m, Faulty_X4_m, Faulty_X5_m]
            X_train_scaled_y_m = scaler_X.transform(True_X_m)
            y_mc = model.predict(X_train_scaled_y_m)
            y_mc = scaler_y.inverse_transform(y_mc)
            y_mc = y_mc[:, 0]
            DQ = np.abs(True_y - y_mc)
            Likeli = normfun(DQ, 0, sigma_LH)
            PR_T1 = normfun(X[0], MeanPrior[0, 0], SigmaPrior[0, 0])
            PR_T2 = normfun(X[1], MeanPrior[0, 1], SigmaPrior[0, 1])
            PR_T3 = normfun(X[2], MeanPrior[0, 2], SigmaPrior[0, 2])
            F = np.prod(Likeli) * (PR_T1 * PR_T2 * PR_T3)
        return F

    def MH_routine(theta, p, proposal_PDF, sample_from_proposal_PDF):
        if Correction_model_expression == "Constant":
            theta = theta[0]
            if isinstance(theta, np.ndarray):
                theta = theta
            else:
                theta = np.array([theta])
        elif Correction_model_expression == "Linear":
            theta = np.squeeze(theta)
        elif Correction_model_expression == "Polynomial":
            theta = np.squeeze(theta)
        theta_ast = sample_from_proposal_PDF(theta)
        alpha = p(theta_ast) * proposal_PDF(theta, theta_ast) / (
                p(theta) * proposal_PDF(theta_ast, theta))
        rand = np.random.uniform(0, 1)
        if np.isnan(alpha):
            alpha = 1e9
        if rand <= np.min([alpha, 1]):
            t = theta_ast
            prob = np.min([alpha, 1])
            a = 1
        else:
            t = theta
            prob = 1 - np.min([alpha, 1])
            a = 0
        return t, a, prob, alpha

    for ii in range(1, 2):
        for ih in range(120, 121):
            NumberState = ih
            EER = 1
            N = 1000
            burnin = 200
            lag = 1

            sigma_PP = 0.001
            sigma_LH = 5

            True_X1_m = X1_m[0:120]
            True_X2_m = X2_m[0:120]
            True_X3_m = X3_m[0:120]
            True_X4_m = X4_m[0:120]
            True_X5_m = X5_m[0:120]
            True_y_m = y_m[0:120]
            highest_corr_variable = highest_corr_variable[0:120]
            ## Faulty measurement
            Faulty_X1_m = True_X1_m
            Faulty_X2_m = True_X2_m
            Faulty_X3_m = True_X3_m
            Faulty_X4_m = True_X4_m
            Faulty_X5_m = True_X5_m
            Faulty_y_m = True_y_m
            Faulty_y_m = np.array(True_y_m) - EER
            highest_corr_variable = np.array(highest_corr_variable)

            if Correction_model_expression == "Constant":
                ## Calibration
                NumberDP = 1
                # Prior distributions
                MeanPrior = np.zeros((1, NumberDP))
                SigmaPrior = np.zeros((1, 1))
                SigmaPrior[0, 0] = 1  # T1
            elif Correction_model_expression == "Linear":
                ## Calibration
                NumberDP = 2
                # Prior distributions
                MeanPrior = np.zeros((1, NumberDP))
                SigmaPrior = np.zeros((1, 2))
                SigmaPrior[0, 0] = 1
                SigmaPrior[0, 1] = 1
            elif Correction_model_expression == "Polynomial":
                NumberDP = 3
                MeanPrior = np.zeros((1, NumberDP))
                SigmaPrior = np.zeros((1, 3))
                SigmaPrior[0, 0] = 1
                SigmaPrior[0, 1] = 1
                SigmaPrior[0, 2] = 1

            # MCMC
            theta = np.zeros((NumberDP, N))
            for i in range(50):
                acc = 0  # Accepted samples
                sigma = np.eye(NumberDP) * sigma_PP
                t = np.zeros((1, NumberDP))

                # M-H routine
                p = lambda X: LJTACmodel_bench_CS(X, sigma_LH, MeanPrior, SigmaPrior, Faulty_y_m, Faulty_X1_m,
                                                  Faulty_X2_m, Faulty_X3_m, Faulty_X4_m, Faulty_X5_m, NumberState,
                                                  highest_corr_variable)
                proposal_PDF = lambda X, mu: multivariate_normal.pdf(X, mean=mu, cov=sigma)
                sample_from_proposal_PDF = lambda mu: np.random.multivariate_normal(mu, sigma)
                for i in range(burnin):
                    t, a, prob, alpha = MH_routine(t, p, proposal_PDF, sample_from_proposal_PDF)

                for i in range(N):
                    for j in range(lag):
                        t, a, prob, alpha = MH_routine(t, p, proposal_PDF,
                                                       sample_from_proposal_PDF);
                    theta[:, i] = t
                    acc = acc + a

                accrate = acc / N
                print('NumberState=', ih)
                print('Acceptance rate=', accrate)
                if accrate < 1:
                    break
        if Correction_model_expression == "Constant":
            m_median = np.zeros((1, 1))
            std_theta = np.zeros((1, 1))
            m_median[0, 0] = np.median(theta[0, :])
            std_theta[0, 0] = np.std(theta[0, :])
        elif Correction_model_expression == "Linear":
            m_median = np.zeros((1, 2))
            std_theta = np.zeros((1, 2))
            m_median[0, 0] = np.median(theta[0, :])
            std_theta[0, 0] = np.std(theta[0, :])
            m_median[0, 1] = np.median(theta[1, :])
            std_theta[0, 1] = np.std(theta[1, :])
        elif Correction_model_expression == "Polynomial":
            m_median = np.zeros((1, 3))
            std_theta = np.zeros((1, 3))
            m_median[0, 0] = np.median(theta[0, :])
            std_theta[0, 0] = np.std(theta[0, :])
            m_median[0, 1] = np.median(theta[1, :])
            std_theta[0, 1] = np.std(theta[1, :])
            m_median[0, 2] = np.median(theta[2, :])
            std_theta[0, 2] = np.std(theta[2, :])
    print(m_median)

    aa = y_m - EER
    cc = y_pred2
    if Correction_model_expression == "Constant":
        bb = aa + m_median
    elif Correction_model_expression == "Linear":
        bb = aa + m_median[0, 0] * highest_corr_variable_all + m_median[0, 1]
    elif Correction_model_expression == "Polynomial":
        bb = aa + m_median[0, 0] * highest_corr_variable_all * highest_corr_variable_all + m_median[
            0, 1] * highest_corr_variable_all + m_median[0, 2]
    plt.figure(figsize=(30, 10))
    plt.plot(cc, color='green', linestyle='-', label='Ground truth')
    plt.plot(aa, color='red', linestyle='-', label='Faulty truth')
    plt.plot(bb, color='blue', linestyle='-', label='Calibration truth')
    plt.xlabel('Time series', fontsize=32)
    plt.ylabel(f'{Calibration_variable}', fontsize=32)
    plt.tick_params(axis='both', which='major', labelsize=30)
    plt.legend(fontsize=32)
    plt.show()

    from sklearn.metrics import r2_score, mean_squared_error

    def Do_scatter(pred1, pred2, pred3, title):
        plt.rcParams['font.family'] = 'times new roman'
        plt.rcParams['figure.figsize'] = [10, 10]
        plt.rc('axes', labelsize=32)
        plt.rc('axes', titlesize=32)
        plt.rc('xtick', labelsize=30)
        plt.rc('ytick', labelsize=30)
        plt.rc('legend', fontsize=32)
        cols = pred1.columns
        f, a = plt.subplots(1, pred1.shape[1], dpi=500)

        R2_1 = r2_score(pred2, pred1)
        RMSE_1 = mean_squared_error(pred2, pred1) ** 0.5

        R2_3 = r2_score(pred2, pred3)
        RMSE_3 = mean_squared_error(pred2, pred3) ** 0.5

        for idx, col in enumerate(cols):
            pred1_, pred2_, pred3_ = pred1[col], pred2[col], pred3[col]
            ax = a[idx] if pred1.shape[1] > 1 else a
            ax.scatter(pred1_, pred2_, s=5, color='k', alpha=1, label='After calibration')
            ax.scatter(pred3_, pred2_, s=5, color='b', alpha=0.7, label='Before calibration')
            xmin, xmax = ax.get_xlim()
            ymin, ymax = ax.get_ylim()
            xlim = [max(xmin, ymin), min(xmax, ymax)]

            ax.plot([max(xmin, ymin) * 0.9, min(xmax, ymax) * 1.1],
                    [max(xmin, ymin) * 0.9, min(xmax, ymax) * 1.1],
                    color='r', ls='--', zorder=100)
            ax.set_xlim(xlim)
            ax.set_ylim(xlim)
            ax.set_xticks(np.linspace(xlim[0], xlim[1], 3).round(1))
            ax.set_yticks(np.linspace(xlim[0], xlim[1], 3).round(1))
            ax.set_xlabel('Predictions')
            ax.set_ylabel('Ground truth')


        plt.suptitle(f'{title}', fontsize=35, x=0.5, y=0.98)
        plt.legend()
        plt.show()

        return RMSE_1, R2_1, RMSE_3, R2_3

    Result_RMSE_1, Result_R2_1, Result_RMSE_3, Result_R2_3 = Do_scatter(pd.DataFrame(bb), pd.DataFrame(cc),pd.DataFrame(aa),'Comparison of before and after calibration')
    plt.show()


    ##
    def load_best_hyperparameters(file_path):
        best_params = {}
        with open(file_path, "r") as f:
            for line in f:
                key, value = line.strip().split(": ")
                try:
                    if "." in value:
                        best_params[key] = float(value)
                    else:
                        best_params[key] = int(value)
                except ValueError:
                    best_params[key] = value
        return best_params

    best_params = load_best_hyperparameters(os.path.join(output_dir,"best_hyperparameters.txt"))
    num_units_1 = best_params['num_units_1']
    num_units_2 = best_params['num_units_2']
    batch_size = best_params['batch_size']
    epochs = best_params['epochs']

    g.add((BRICK[f'{Calibration_variable}'], RDF.type, BRICK.PhysicalSensor))

    g.add((BRICK[f'{Calibration_variable}'], BRICK.hasRMSE_AC, Literal(Result_RMSE_1, datatype=XSD.float)))
    g.add((BRICK[f'{Calibration_variable}'], BRICK.hasRMSE_BC, Literal(Result_RMSE_3, datatype=XSD.float)))

    g.add((BRICK[f'{Calibration_variable}'], BRICK.CalibrationApproach, Literal('Nonintrusive_Direct_Calibration')))

    g.add((BRICK[f'{Calibration_variable}'], BRICK.CalibrationStartTime, Literal(Calibration_start_period)))
    g.add((BRICK[f'{Calibration_variable}'], BRICK.CalibrationEndTime, Literal(Calibration_end_period)))

    g.add((BRICK[most_correlated_variable1], BRICK.isInputOf, Literal(f'{Calibration_variable}_Benchmark_Model')))
    g.add((BRICK[most_correlated_variable2], BRICK.isInputOf, Literal(f'{Calibration_variable}_Benchmark_Model')))
    g.add((BRICK[most_correlated_variable3], BRICK.isInputOf, Literal(f'{Calibration_variable}_Benchmark_Model')))
    g.add((BRICK[most_correlated_variable4], BRICK.isInputOf, Literal(f'{Calibration_variable}_Benchmark_Model')))
    g.add((BRICK[most_correlated_variable5], BRICK.isInputOf, Literal(f'{Calibration_variable}_Benchmark_Model')))

    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Input, Literal(num_units_1)))
    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Input, Literal(num_units_2)))
    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Input, Literal(batch_size)))
    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Input, Literal(epochs)))

    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Uses, Literal('Pearson correlation analysis')))
    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Uses, Literal('Optuna Algorithm')))
    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.Uses, Literal('MLP Algorithm')))

    g.add((BRICK[highest_corr_variable_name], BRICK.isInputOf, Literal(f'{Calibration_variable}_Correction_Model')))
    g.add((BRICK[Correction_model_expression], BRICK.isExpressedBy, Literal(f'{Calibration_variable}_Correction_Model')))

    g.add((BRICK[f'{Calibration_variable}_Benchmark_Model'], BRICK.isInputOf, Literal(f'{Calibration_variable}_Distance_Model')))
    g.add((BRICK[f'{Calibration_variable}_Correction_Model'], BRICK.isInputOf, Literal(f'{Calibration_variable}_Distance_Model')))

    g.add((BRICK[f'{Calibration_variable}'], BRICK.isInputOf, Literal(f'{Calibration_variable}_Distance_Model')))
    g.add((BRICK[f'{Calibration_variable}_Distance_Model'], BRICK.isInputOf, Literal(f'{Calibration_variable}_Problem_Solving')))
    g.add((BRICK[f'{Calibration_variable}_Problem_Solving'], BRICK.Estimates, Literal(f'{Calibration_variable}_Correction_Model')))
    g.add((BRICK[f'{Calibration_variable}_Correction_Model'], BRICK.Calibrates, Literal(Calibration_variable)))

    g.add((BRICK[f'{Calibration_variable}_Problem_Solving'], BRICK.Uses, Literal('Bayesian MCMC')))

    # %%
    with open(os.path.join(output_dir,"Physical_sensor_calibration.ttl"), "w") as f:
        f.write(g.serialize(format="ttl"))

    print('All data created!')
    return f"""
The virtual model or physical sensor has been successfully calibrated, RMSE decrease from {Result_RMSE_3}  to {Result_RMSE_1} .
Result_RMSE_3 represents the difference between the measurements and the faulty value\
Result_RMSE_1 represents the difference between the measurements and the faulty value that has been calibrated
"""

