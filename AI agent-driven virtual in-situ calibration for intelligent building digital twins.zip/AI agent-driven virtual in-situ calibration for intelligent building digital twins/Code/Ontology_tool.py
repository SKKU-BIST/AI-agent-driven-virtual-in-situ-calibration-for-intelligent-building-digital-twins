def Ontology_tool(question):
    import os
    from langchain_openai import ChatOpenAI
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    from langchain_community.document_loaders import TextLoader

    # OPENAI API KEY
    os.environ["OPENAI_API_KEY"] = 'Your api key' #Your api key

    # %%
    current_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(current_dir, "Output")
    # RDF
    loader = TextLoader(os.path.join(output_dir,"Physical_sensor_calibration.ttl"))
    data = loader.load()
    context = data[0].page_content

    # Prompt
    chat_prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a helpful assistant dealing with rdf file about target system."),
        ("assistant", "Please let me know the contents of the ttl file and I will answer you within the file."),
        ("user", 'The contents of the ttl file are {file}.'),
        ("assistant", "I checked all the contents of the file. Now ask me questions."),
        ("user", "{question}"),
    ])

    # Chaining
    model = ChatOpenAI(model_name='gpt-4o', temperature=0)
    output_parser = StrOutputParser()
    chain = chat_prompt | model | output_parser

    response = chain.invoke({"file": context, "question": question})

    return response