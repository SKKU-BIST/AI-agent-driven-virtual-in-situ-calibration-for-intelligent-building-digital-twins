def Benchmark_modeling_tool(Calibration_variable):
    import numpy as np
    import tensorflow as tf
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler, MinMaxScaler
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif'] = 'Times New Roman'  # font set
    import time, os
    import pandas as pd
    import pickle
    from rdflib import Graph, Namespace, RDF, Literal
    from sklearn.metrics import mean_squared_error
    import optuna

    current_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(current_dir, "Input")
    output_dir = os.path.join(current_dir, "Output")



    # Define the namespace
    BRICK = Namespace("https://brickschema.org/schema/1.2/Brick#")

    # Load the TTL file
    ttl_file_path = os.path.join(input_dir, "my_building_sensor.ttl")
    g = Graph()
    g.parse(ttl_file_path, format="ttl")

    # Query all objects under the brick1 namespace
    query = """
        SELECT DISTINCT ?object
        WHERE {
            ?s ?p ?object .
            FILTER(STRSTARTS(STR(?object), "https://brickschema.org/schema/1.2/Brick#"))
        }
    """

    # Execute a SPARQL query
    results = g.query(query)
    brick1_objects = [str(row.object).replace("https://brickschema.org/schema/1.2/Brick#", "") for row in results]
    brick1_objects_sorted = sorted(brick1_objects)

    df = pd.read_csv(os.path.join(input_dir, "HVAC operational dataset for final project (final).csv"), index_col=0,header=2, encoding='CP949')
    training_start_period = '2022-06-01'
    training_end_period = '2022-06-20'
    Input_variable1 = brick1_objects_sorted

    if df.index[0].count('.') == 2:
        df.index = pd.to_datetime(df.index, format="%d.%m.%Y %H:%M")
    else:
        df.index = pd.to_datetime(df.index, format="%m %d %H").map(lambda x: x.replace(year=2022))

    df_ = df.loc[training_start_period:training_end_period, :]

    data = {
        "Supply_Condenser_Water_Temperature": df_[Input_variable1].values[:, 28],
        "Return_Condenser_Water_Temperature": df_[Input_variable1].values[:, 23],
        "Supply_Chilled_Water_Temperature": df_[Input_variable1].values[:, 27],
        "Return_Chilled_Water_Temperature": df_[Input_variable1].values[:, 22],
        "Cooling_Mass_Flow": df_[Input_variable1].values[:, 5],
        "Chilled_Mass_Flow": df_[Input_variable1].values[:, 1],
        "Power": df_[Input_variable1].values[:, 19],
        "Cooling_Water_Differential_Pressure": df_[Input_variable1].values[:, 6],
        "Chilled_water_Differential_Pressure": df_[Input_variable1].values[:, 4],
        "Fan_Speed": df_[Input_variable1].values[:, 10],
        "Static_Pressure": df_[Input_variable1].values[:, 24],
        "Supply_Air_Temperature": df_[Input_variable1].values[:, 26],
        "Supply_Air_Humidity": df_[Input_variable1].values[:, 25],
        "Mixed_Air_Temperature": df_[Input_variable1].values[:, 16],
        "Mixed_Air_Humidity": df_[Input_variable1].values[:, 15],
        "Outdoor_Air_Temperature": df_[Input_variable1].values[:, 18],
        "Outdoor_Air_Humidity": df_[Input_variable1].values[:, 17],
        "Return_Air_Temperature": df_[Input_variable1].values[:, 21],
        "Return_Air_Humidity": df_[Input_variable1].values[:, 20],
        "Valve_Opening": df_[Input_variable1].values[:, 35],
        "Indoor_Air_Temperature1": df_[Input_variable1].values[:, 12],
        "Indoor_Air_Temperature2": df_[Input_variable1].values[:, 13],
        "Indoor_Air_Temperature3": df_[Input_variable1].values[:, 14],
    }

    data = pd.DataFrame(data)



    # Calculate the correlation matrix
    correlation_matrix = data.corr()
    correlation_with_variable = correlation_matrix[Calibration_variable].drop(labels=Calibration_variable)
    correlation_with_variable_sorted = correlation_with_variable.sort_values(ascending=False)
    most_correlated_variables = correlation_with_variable_sorted.index[0:5]
    new_columns_1_5 = data[list(most_correlated_variables)]
    X = new_columns_1_5
    X.columns = [0, 1, 2, 3, 4]
    y = df_[Calibration_variable].values.reshape(-1, 1)
    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()
    X = scaler_X.fit_transform(X)
    y = scaler_y.fit_transform(y)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Define the objective function for optimization
    def objective(trial):
        num_units_1 = trial.suggest_int('num_units_1', 32, 256, step=32)
        num_units_2 = trial.suggest_int('num_units_2', 16, 128, step=16)
        batch_size = trial.suggest_categorical('batch_size', [16, 32, 64])
        epochs = trial.suggest_int('epochs', 10, 50)
        model = tf.keras.Sequential([
            tf.keras.layers.Dense(num_units_1, activation='relu', input_shape=(X_train.shape[1],)),
            tf.keras.layers.Dense(num_units_2, activation='relu'),
            tf.keras.layers.Dense(1)
        ])

        model.compile(optimizer='adam', loss='mean_squared_error')

        model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=0, validation_split=0.2)

        y_pred = model.predict(X_test)
        rmse = mean_squared_error(y_test, y_pred, squared=False)
        return rmse

    # Use Optuna for hyperparameter optimization
    study = optuna.create_study(direction='minimize')
    study.optimize(objective, n_trials=10)
    with open(os.path.join(output_dir,"best_hyperparameters.txt"), "w") as f:
        for key, value in study.best_params.items():
            f.write(f"{key}: {value}\n")

    # Calculate the correlation matrix
    correlation_matrix = data.corr()
    correlation_with_variable = correlation_matrix[Calibration_variable].drop(labels=Calibration_variable)
    correlation_with_variable_sorted = correlation_with_variable.sort_values(ascending=False)
    most_correlated_variables = correlation_with_variable_sorted.index[0:5]
    Input_variable=most_correlated_variables
    most_correlated_variables1 = correlation_with_variable_sorted.index[0]
    with open(os.path.join(output_dir,"most_correlated_variables1.txt"), "w") as file:
        file.write(most_correlated_variables1)
    most_correlated_variables2 = correlation_with_variable_sorted.index[1]
    with open(os.path.join(output_dir,"most_correlated_variables2.txt"), "w") as file:
        file.write(most_correlated_variables2)
    most_correlated_variables3 = correlation_with_variable_sorted.index[2]
    with open(os.path.join(output_dir,"most_correlated_variables3.txt"), "w") as file:
        file.write(most_correlated_variables3)
    most_correlated_variables4 = correlation_with_variable_sorted.index[3]
    with open(os.path.join(output_dir,"most_correlated_variables4.txt"), "w") as file:
        file.write(most_correlated_variables4)
    most_correlated_variables5 = correlation_with_variable_sorted.index[4]
    with open(os.path.join(output_dir,"most_correlated_variables5.txt"), "w") as file:
        file.write(most_correlated_variables5)

    new_columns_1_5 = data[list(most_correlated_variables)]
    X = new_columns_1_5
    X.columns = [0, 1, 2, 3, 4]
    y = df_[Calibration_variable].values.reshape(-1, 1)
    y = pd.DataFrame(y)

    Number=len(y)

    X = pd.DataFrame(X)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 데이터 정규화
    scaler_X = MinMaxScaler()
    scaler_y = MinMaxScaler()

    X_train_scaled = scaler_X.fit_transform(X_train)
    y_train_scaled = scaler_y.fit_transform(y_train)

    X_test_scaled = scaler_X.transform(X_test)
    y_test_scaled = scaler_y.transform(y_test)

    with open(os.path.join(output_dir,"scaler_X.pkl"), "wb") as f:
        pickle.dump(scaler_X, f)

    with open(os.path.join(output_dir,"scaler_y.pkl"), "wb") as f:
        pickle.dump(scaler_y, f)

    def load_best_hyperparameters(file_path):
        best_params = {}
        with open(file_path, "r") as f:
            for line in f:
                key, value = line.strip().split(": ")
                try:
                    # 自动解析为整数或浮点数
                    if "." in value:
                        best_params[key] = float(value)
                    else:
                        best_params[key] = int(value)
                except ValueError:
                    # 如果不能转为数字，则保留为字符串
                    best_params[key] = value
        return best_params

    best_params = load_best_hyperparameters(os.path.join(output_dir,"best_hyperparameters.txt"))
    #best_params = load_best_hyperparameters("C:/Study/BaiduSyncdisk/02_Ontological VIC/Code6/best_hyperparameters.txt")
    num_units_1 = best_params['num_units_1']
    num_units_2 = best_params['num_units_2']
    batch_size = best_params['batch_size']
    epochs = best_params['epochs']

    model = tf.keras.Sequential([
        tf.keras.layers.Dense(num_units_1, activation='relu', input_shape=(X_train_scaled.shape[1],)),
        tf.keras.layers.Dense(num_units_2, activation='relu'),
        tf.keras.layers.Dense(1)
    ])

    model.compile(optimizer='adam', loss='mean_squared_error')

    validation_split = 0.2
    model.fit(X_train_scaled, y_train_scaled, epochs=epochs, batch_size=batch_size, validation_split=validation_split,
              verbose=0)
    y_train_pred = model.predict(X_train_scaled)
    y_train_pred = pd.DataFrame(scaler_y.inverse_transform(y_train_pred))

    model.save(os.path.join(output_dir,f'{Calibration_variable}_VM' + ".h5"))

    loss = model.evaluate(X_test_scaled, y_test_scaled)

    # 예측
    y_pred_scaled = model.predict(X_test_scaled)
    y_pred_test = pd.DataFrame(scaler_y.inverse_transform(y_pred_scaled))

    # %%

    def Do_scatter(pred1, pred2, title):
        plt.rcParams['font.family'] = 'times new roman'
        plt.rcParams['figure.figsize'] = [9, 9]
        plt.rc('axes', labelsize=25)
        plt.rc('axes', titlesize=25)
        plt.rc('xtick', labelsize=25)
        plt.rc('ytick', labelsize=25)
        plt.rc('legend', fontsize=20)
        plt.rc('figure', titlesize=25)
        cols = pred1.columns
        f, a = plt.subplots(1, pred1.shape[1], dpi=500)

        from sklearn.metrics import r2_score
        from sklearn.metrics import mean_squared_error
        R2 = r2_score(pred2, pred1)
        RMSE = mean_squared_error(pred2, pred1) ** (1 / 2)

        for idx, col in enumerate(cols):
            pred1_, pred2_ = pred1[col], pred2[col]
            ax = a[idx] if pred1.shape[1] > 1 else a
            ax.scatter(pred1_, pred2_, s=5, color='k', alpha=1)
            xmin, xmax = ax.get_xlim()
            ymin, ymax = ax.get_ylim()
            xlim = [max(xmin, ymin), min(xmax, ymax)]

            ax.plot([max(xmin, ymin) * 0.9, min(xmax, ymax) * 1.1], [max(xmin, ymin) * 0.9, min(xmax, ymax) * 1.1],
                    color='r', ls='--', zorder=100)
            ax.set_xlim(xlim)
            ax.set_ylim(xlim)
            ax.set_xticks(np.linspace(xlim[0], xlim[1], 3).round(1))
            ax.set_yticks(np.linspace(xlim[0], xlim[1], 3).round(1))
            ax.set_xlabel('Prediction')
            ax.set_ylabel('Ground truth')
            ax.set_title(f'(RMSE: {RMSE:.3f})', fontsize=25)

        # plt.subplots_adjust(wspace=.7, bottom=.6)
        plt.suptitle(f'{title}', fontsize=35, x=0.5, y=0.97)
        plt.show()

        return RMSE, R2

    Result_RMSE, Result_R2 = Do_scatter(y_pred_test, y_test, f'{Calibration_variable}')

