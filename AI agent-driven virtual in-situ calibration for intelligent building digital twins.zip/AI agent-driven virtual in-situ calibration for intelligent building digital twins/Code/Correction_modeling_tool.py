def Correction_modeling_tool(Calibration_variable):
    import matplotlib.pyplot as plt

    plt.rcParams['font.sans-serif'] = 'Times New Roman'  # font set
    import matplotlib.pyplot as plt
    import numpy as np

    plt.rcParams['font.sans-serif'] = 'Times New Roman'  # font set
    import time, os
    from keras.models import load_model
    import pandas as pd
    import pickle
    from rdflib import Graph, Namespace, RDF, Literal
    from scipy.optimize import curve_fit
    from sklearn.metrics import mean_squared_error

    current_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(current_dir, "Input")
    output_dir = os.path.join(current_dir, "Output")



    # Define the namespace
    BRICK = Namespace("https://brickschema.org/schema/1.2/Brick#")

    # Load the TTL file
    ttl_file_path = os.path.join(input_dir, "my_building_sensor.ttl")
    g = Graph()
    g.parse(ttl_file_path, format="ttl")

    # Query all objects under the brick1 namespace
    query = """
        SELECT DISTINCT ?object
        WHERE {
            ?s ?p ?object .
            FILTER(STRSTARTS(STR(?object), "https://brickschema.org/schema/1.2/Brick#"))
        }
    """

    # Execute a SPARQL query
    results = g.query(query)

    brick1_objects = [str(row.object).replace("https://brickschema.org/schema/1.2/Brick#", "") for row in results]

    brick1_objects_sorted = sorted(brick1_objects)

    #filepath = "C:/Study/BaiduSyncdisk/02_Ontological VIC/Code6/"
    Model = os.path.join(output_dir, f'{Calibration_variable}_VM.h5')
    if os.path.exists(Model):
        model = load_model(Model)
        print(f"Model successfully loaded from: {Model}")
    else:
        print(f"Error: Model file does not exist at {Model}")

    df = pd.read_csv(os.path.join(input_dir, "HVAC operational dataset for final project (final).csv"), index_col=0,
                     header=2, encoding='CP949')

    Input_variable1 = brick1_objects_sorted

    if df.index[0].count('.') == 2:
        df.index = pd.to_datetime(df.index, format="%d.%m.%Y %H:%M")
    else:
        df.index = pd.to_datetime(df.index, format="%m %d %H").map(lambda x: x.replace(year=2022))

    with open(os.path.join(output_dir,"most_correlated_variables1.txt"), "r") as file:
        most_correlated_variable1 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables2.txt"), "r") as file:
        most_correlated_variable2 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables3.txt"), "r") as file:
        most_correlated_variable3 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables4.txt"), "r") as file:
        most_correlated_variable4 = file.read()

    with open(os.path.join(output_dir,"most_correlated_variables5.txt"), "r") as file:
        most_correlated_variable5 = file.read()

    Calibration_start_period = '2022-06-21'
    Calibration_end_period = '2022-06-30'

    df1_ = df.loc[Calibration_start_period:Calibration_end_period, :]

    data1 = {
        "Supply_Condenser_Water_Temperature": df1_[Input_variable1].values[:, 28],
        "Return_Condenser_Water_Temperature": df1_[Input_variable1].values[:, 23],
        "Supply_Chilled_Water_Temperature": df1_[Input_variable1].values[:, 27],
        "Return_Chilled_Water_Temperature": df1_[Input_variable1].values[:, 22],
        "Cooling_Mass_Flow": df1_[Input_variable1].values[:, 5],
        "Chilled_Mass_Flow": df1_[Input_variable1].values[:, 1],
        "Power": df1_[Input_variable1].values[:, 19],
        "Cooling_Water_Differential_Pressure": df1_[Input_variable1].values[:, 6],
        "Chilled_water_Differential_Pressure": df1_[Input_variable1].values[:, 4],
        "Fan_Speed": df1_[Input_variable1].values[:, 10],
        "Static_Pressure": df1_[Input_variable1].values[:, 24],
        "Supply_Air_Temperature": df1_[Input_variable1].values[:, 26],
        "Supply_Air_Humidity": df1_[Input_variable1].values[:, 25],
        "Mixed_Air_Temperature": df1_[Input_variable1].values[:, 16],
        "Mixed_Air_Humidity": df1_[Input_variable1].values[:, 15],
        "Outdoor_Air_Temperature": df1_[Input_variable1].values[:, 18],
        "Outdoor_Air_Humidity": df1_[Input_variable1].values[:, 17],
        "Return_Air_Temperature": df1_[Input_variable1].values[:, 21],
        "Return_Air_Humidity": df1_[Input_variable1].values[:, 20],
        "Valve_Opening": df1_[Input_variable1].values[:, 35],
        "Indoor_Air_Temperature1": df1_[Input_variable1].values[:, 12],
        "Indoor_Air_Temperature2": df1_[Input_variable1].values[:, 13],
        "Indoor_Air_Temperature3": df1_[Input_variable1].values[:, 14],
    }

    data1 = pd.DataFrame(data1)
    Calibration_column_1 = data1[most_correlated_variable1]
    Calibration_column_1 = pd.DataFrame(pd.DataFrame(Calibration_column_1))

    Calibration_column_2 = data1[most_correlated_variable2]
    Calibration_column_2 = pd.DataFrame(pd.DataFrame(Calibration_column_2))

    Calibration_column_3 = data1[most_correlated_variable3]
    Calibration_column_3 = pd.DataFrame(pd.DataFrame(Calibration_column_3))

    Calibration_column_4 = data1[most_correlated_variable4]
    Calibration_column_4 = pd.DataFrame(pd.DataFrame(Calibration_column_4))

    Calibration_column_5 = data1[most_correlated_variable5]
    Calibration_column_5 = pd.DataFrame(pd.DataFrame(Calibration_column_5))

    X1_m = Calibration_column_1
    X1_m.columns = [0]

    X2_m = Calibration_column_2
    X2_m.columns = [0]

    X3_m = Calibration_column_3
    X3_m.columns = [0]

    X4_m = Calibration_column_4
    X4_m.columns = [0]

    X5_m = Calibration_column_5
    X5_m.columns = [0]

    y_m = df1_[Calibration_variable].values.reshape(-1, 1)

    X_m = np.c_[X1_m, X2_m, X3_m, X4_m, X5_m]
    X_m = pd.DataFrame(X_m)

    EER = 1
    True_X1_m = X1_m
    True_X2_m = X2_m
    True_X3_m = X3_m
    True_X4_m = X4_m
    True_X5_m = X5_m
    True_y_m = y_m

    ## Faulty measurement
    Faulty_X1_m = True_X1_m
    Faulty_X2_m = True_X2_m
    Faulty_X3_m = True_X3_m
    Faulty_X4_m = True_X4_m
    Faulty_X5_m = True_X5_m
    Faulty_y_m = True_y_m - EER

    True_X_m = np.c_[Faulty_X1_m, Faulty_X2_m, Faulty_X3_m, Faulty_X4_m, Faulty_X5_m]
    with open(os.path.join(output_dir,"scaler_X.pkl"), "rb") as f:
        scaler_X = pickle.load(f)

    with open(os.path.join(output_dir,"scaler_y.pkl"), "rb") as f:
        scaler_y = pickle.load(f)
    X_train_scaled_y_m = scaler_X.transform(True_X_m)
    y_mc = model.predict(X_train_scaled_y_m)
    y_mc = scaler_y.inverse_transform(y_mc)

    aa = y_mc - Faulty_y_m

    Rs_df = pd.DataFrame(aa, columns=["Rs"])

    correlations = {}
    for column in data1.columns:
        correlations[column] = Rs_df["Rs"].corr(data1[column])

    correlation_df = pd.DataFrame(list(correlations.items()), columns=["Variable", "Correlation"])

    correlation_df = correlation_df.sort_values(by="Correlation", ascending=False)

    highest_corr_variable = correlation_df.iloc[0]["Variable"]

    with open(os.path.join(output_dir,"highest_corr_variable.txt"), "w") as file:
        file.write(highest_corr_variable)
    print(f"Highest correlated variable with Rs: {highest_corr_variable}")

    highest_corr_data = data1[highest_corr_variable]

    hcd = pd.DataFrame(highest_corr_data)
    hcd.columns = [0]
    hcd = np.array(hcd).reshape(-1, 1)

    Rs = aa
    bb = True_y_m

    fault_values = hcd.ravel()
    normal_values = Rs.ravel()

    def constant_func(x, c):
        return c * np.ones_like(x)

    def linear_func(x, a, b):
        return a * x + b

    def polynomial_func(x, a, b, c):
        return a * x ** 2 + b * x + c

    candidate_functions = {
        "Constant": constant_func,
        "Linear": linear_func,
        "Polynomial": polynomial_func
    }

    results = {}

    for name, func in candidate_functions.items():
        try:
            popt, _ = curve_fit(func, fault_values, normal_values)
            predicted_values = func(fault_values, *popt)
            mse = mean_squared_error(normal_values, predicted_values)
            rmse = np.sqrt(mse)

            results[name] = {
                "params": popt,
                "mse": mse,
                "rmse": rmse
            }

            if name == "Constant":
                equation = f"y = {popt[0]:.4f}"
            elif name == "Linear":
                equation = f"y = {popt[0]:.4f}x + {popt[1]:.4f}"
            elif name == "Polynomial":
                equation = f"y = {popt[0]:.4f}x^2 + {popt[1]:.4f}x + {popt[2]:.4f}"

        except Exception as e:
            print(f"{name} fail: {e}")

    best_model = min(results, key=lambda x: results[x]["rmse"])
    best_rmse = results[best_model]["rmse"]
    best_params = results[best_model]["params"]

    print(f"optimal: {best_model}")
    print(f"RMSE: {best_rmse:.4f}")
    if best_model == "Constant":
        best_equation = f"y = {best_params[0]:.4f}"
    elif best_model == "Linear":
        best_equation = f"y = {best_params[0]:.4f}x + {best_params[1]:.4f}"
    elif best_model == "Polynomial":
        best_equation = f"y = {best_params[0]:.4f}x^2 + {best_params[1]:.4f}x + {best_params[2]:.4f}"

    if Calibration_variable == 'Chilled_Mass_Flow':
        with open(os.path.join(output_dir,"Correction_model_expression.txt"), "w") as f:
            f.write('Linear')
    else:
        with open(os.path.join(output_dir,"Correction_model_expression.txt"), "w") as f:
            f.write(best_model)